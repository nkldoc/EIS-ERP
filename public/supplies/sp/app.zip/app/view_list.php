<?php
$path = 'D:/Documents/Sys/supplies/2025/procure'; // หรือ path ที่คุณต้องการ
$files = [];

$iterator = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)
);

foreach ($iterator as $fileinfo) {
    if ($fileinfo->isFile()) {
        $relativePath = str_replace('\\', '/', $fileinfo->getPathname());
        $files[] = $relativePath;
    }
}

header('Content-Type: application/json');
echo json_encode($files);
