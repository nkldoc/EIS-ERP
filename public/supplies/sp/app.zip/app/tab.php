<!DOCTYPE html>
<html lang="th">
    <head>
        <meta charset="utf-8" />
        <title>Bookmarks – ExtJS 3.4 TreeGrid (Maximgb) CRUD</title>

        <!-- ExtJS 3.4 -->
        <link href="../../js/ext-3.4.0/resources/css/ext-all.css" rel="stylesheet" type="text/css"/>
        <script src="js/extjs3.4.1-1/ext-base.js" type="text/javascript"></script>
        <script src="js/extjs3.4.1-1/ext-all.js" type="text/javascript"></script>

        <!-- Maximgb TreeGrid (ไม่จำเป็นต่อแท็บ แต่คงไว้ตามสโคปเดิม) -->
        <link rel="stylesheet" href="./css/maximgb-treegrid.css" />
        <script src="../../js/TreeGrid/TreeGrid.js"></script>

        <style>
            html, body {
                height:100%;
            }
            body{
                margin:0px
            }
            .hit{
                animation:hitpulse 1s ease-in-out 0s 2;
                background:#fffae6!important
            }
            @keyframes hitpulse{
                0%{
                    background:#fff3b0
                }
                50%{
                    background:#fff
                }
                100%{
                    background:#fff3b0
                }
            }
            .badge-1,.badge-2,.badge-3,.badge-4{
                padding:2px 6px;
                border-radius:10px;
                border:1px solid
            }
            .badge-1{
                background:#f5f5f5;
                color:#555;
                border-color:#ddd
            }
            .badge-2{
                background:#fff7e6;
                color:#a35d00;
                border-color:#ffd59c
            }
            .badge-3{
                background:#e8ffe8;
                color:#2b8a3e;
                border-color:#bfe8bf
            }
            .badge-4{
                background:#c00;
                color:#fff;
                border-color:#bfe8bf
            }
            a.clear-dt{
                color:#c00;
                text-decoration:underline
            }

            /* ให้ iframe กินเต็มพื้นที่แท็บ */
            .tab-iframe {
                width:100%;
                height:100%;
                border:0;
            }
            /* ทำให้ TabPanel สูงเต็มหน้าจอ (เมื่อไม่ใช้ Viewport) */
            #tabs-wrap, #tabs-panel {
                height: calc(100vh - 24px);
            }
        </style>
    </head>
    <body>
        <div id="tabs-wrap"></div>

        <script>
            Ext.BLANK_IMAGE_URL = '../../js/ext-3.4.0/resources/images/default/s.gif';

            // ====== ตั้งค่า URL ปลายทางของแต่ละแท็บ (แก้ไขได้ตามระบบจริง) ======
            var PR_URL = '../CheckList.php';    // ตัวอย่าง: หน้า PR
            var TOR_TYPE = './mnBookmarkTemplate.php';    // ตัวอย่าง: หน้า PR
            var SIGN_URL = './mnBookmark.php';              // ตัวอย่าง: หน้าลงนามเอกสาร
            var AUDITOR_URL = './mnBookmarkAllStatus.php';              // ตัวอย่าง: หน้าผู้ตรวจสอบ
            
            // ยูทิลช่วยสร้าง iframe ภายในแท็บ
            function iframeHtml(url) {
                return '<iframe class="tab-iframe" src="' + url + '" loading="lazy"></iframe>';
            }

            // ดึง iframe ของแท็บปัจจุบัน
            function getTabIframe(tab) {
                if (!tab)
                    return null;
                var el = tab.body ? tab.body.dom : tab.getEl().dom;
                return el ? el.querySelector('iframe.tab-iframe') : null;
            }

            Ext.onReady(function () {
                Ext.QuickTips.init();

                // ปุ่มรีเฟรช iframe ของแท็บที่เลือกอยู่
                var refreshBtn = new Ext.Button({
                    text: 'รีเฟรชแท็บ',
                    id:'refresh-parentID',
                    iconCls: 'x-tbar-loading',
                    handler: function () {
                        var active = tabs.getActiveTab();
                        var ifr = getTabIframe(active);
                        if (ifr) {
                            // รีโหลดแบบไม่เปลี่ยนค่า src (คง query string ไว้)
                            try {
                                ifr.contentWindow.location.reload();
                            } catch (e) {
                                ifr.src = ifr.src;
                            }
                        }
                    }
                });
 Ext.spTypeStatusStore = new Ext.data.ArrayStore({
    fields: ['value', 'text'],
    data: [
        [1, 'เฉพาะเจาะจง'],
        [2, 'e-market'],
        [3, 'คัดเลือก'],
        [4, 'e-bidding']
    ]
});

Ext.getText = function(store, val) {
    var result = '';
    (store.data.items || []).forEach(function(rec) {
        if (rec.get('value') == val) {
            result = rec.get('text').toUpperCase();
        }
    });
    return "["+result+"]";
};
                // ปุ่มเปิดในหน้าต่างใหม่
                var popoutBtn = new Ext.Button({
                    text: 'เปิดหน้าต่างใหม่',
                    handler: function () {
                        var active = tabs.getActiveTab();
                        var ifr = getTabIframe(active);
                        if (ifr && ifr.src) {
                            window.open(ifr.src, '_blank');
                        }
                    }
                });
                Ext.globValue = null;
         
                // ====== สร้าง TabPanel ======
                var tabs = new Ext.TabPanel({
                    id: 'tabs-panel-sign',
                    activeTab: 0,
                    enableTabScroll: true,
                    border: true,
                    defaults: {layout: 'fit', autoScroll: false, border: false},
//                    tbar: [refreshBtn, '-', popoutBtn, '->', {xtype: 'tbtext', text: 'PR / TOR TYPE / Sign / Auditor'}],
                    tbar: [refreshBtn, '->', {xtype: 'tbtext', text: 'PR / TOR TYPE /Auditor/ Sign '}],
                    items: [
                        {
                            title: 'PR',
                            id: 'tab-pr',
                            html: iframeHtml(PR_URL),
                            iconCls: 'icon-pr'
                        },
                        {
                            title: 'ชุดเอกสาร/วิธีการดำเนินงาน',
                            id: 'tab-template',
                            html: iframeHtml(TOR_TYPE),
                            iconCls: 'icon-audit'
                            
                        },
                        {
                            title: 'ตรวจสอบเอกสาร Auditor',
                            id: 'tab-auditor',
                            html: iframeHtml(AUDITOR_URL),
                            iconCls: 'icon-audit'
                        },
                        {
                            title: 'ลงนาม Sign',
                            id: 'tab-sign',
                            html: iframeHtml(SIGN_URL),
                            iconCls: 'icon-sign'
                        }
                    ],
                    listeners: {
                        tabchange: function (tp, newTab) {
                            // ถ้าอยาก reload iframe ตอนสลับ tab
                             var ifr = getTabIframe(newTab); 
                             if(ifr){ try{ ifr.contentWindow.location.reload(); }catch(e){ ifr.src = ifr.src; } }
                        }
                    }
                });

// ====== Viewport เต็มจอ ======
                var App = new Ext.Viewport({
                    layout: "fit", // fit layout = ขยายเต็ม
                    items: [tabs]
                });

// set tab แรกให้ active
                tabs.setActiveTab('tab-pr');

            });

        </script>
    </body>
</html>
