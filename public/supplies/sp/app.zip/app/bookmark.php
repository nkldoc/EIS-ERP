<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8" />
  <title>PDF Manager</title>

  <!-- PDF.js (CDN + worker) -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js"></script>
  <script>
    pdfjsLib.GlobalWorkerOptions.workerSrc =
      "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
  </script>

  <style>
    body { font-family: Arial, sans-serif; margin: 16px; }
    #cols { display: grid; grid-template-columns: 340px 1fr; gap: 16px; }
    #bookmarkList, #serverFiles { border: 1px solid #aaa; padding: 8px; max-height: 220px; overflow-y: auto; }
    .bookmark { cursor: pointer; margin: 2px 0; }
    #pdfContainer { border: 1px solid #ccc; height: 80vh; overflow-y: scroll; padding: 8px; }
    label { display:block; margin-top: 8px; }
    .row { display:flex; gap:8px; align-items: center; flex-wrap: wrap;}
    button { padding: 6px 12px; }
    small.muted { color:#777; }
  </style>
</head>
<body>
  <h2>PDF Manager</h2>

  <div class="row">
    <form id="templateForm" enctype="multipart/form-data" method="post" action="/supplies/pdf/uploadTemplate">
      <label><b>อัปโหลด Template (PDF ที่มี bookmark):</b></label>
      <input type="file" name="templatePdf" accept="application/pdf" required />
      <button type="submit">อัปโหลด</button>
      <small class="muted">ตัวอย่าง: ไม่เกินห้าแสน_bookmark.pdf</small>
    </form>
    <button id="btnReload">รีเฟรช Bookmarks/Preview</button>
  </div>

  <div id="cols">
    <div>
      <h3>Bookmarks</h3>
      <div id="bookmarkList">—</div>

      <h3>จัดการหน้า</h3>
      <form id="editForm" enctype="multipart/form-data">
        <label>หมายเลขหน้าเริ่ม (1-based):</label>
        <input type="number" name="pageNumber" id="pageNumber" min="1" required />

        <label>การทำงาน:</label>
        <select name="actionType" id="actionType">
          <option value="insert">แทรกหน้าใหม่</option>
          <option value="replace">แทนที่หน้าเดียว</option>
          <option value="replaceRange">แทนที่หลายหน้า (ช่วง)</option>
        </select>

        <div id="replaceCountWrap" style="display:none">
          <label>จำนวนหน้าที่จะถูกแทนที่ (replaceCount):</label>
          <input type="number" name="replaceCount" id="replaceCount" min="1" value="1" />
          <small class="muted">เช่น เริ่มที่หน้า 5 และ replaceCount=3 → แทนที่หน้า 5-7</small>
        </div>

        <label>เลือก PDF ใหม่ (อัปโหลด):</label>
        <input type="file" name="newPdf" id="newPdf" accept="application/pdf" />

        <div class="row">
          <label>หรือเลือกจากเซิร์ฟเวอร์:</label>
          <select name="serverFile" id="serverFile">
            <option value="">—</option>
          </select>
          <button type="button" id="btnReloadServerFiles">รีเฟรชไฟล์</button>
        </div>

        <div class="row">
          <button type="submit">ยืนยัน</button>
          <span id="editMsg"></span>
        </div>
        <small class="muted">
          * ถ้าไฟล์ต้นทางมีหลายหน้า ระบบจะ <b>แทรก/แทนที่ด้วยทุกหน้า</b> ตามลำดับในไฟล์นั้น
        </small>
      </form>

      <h3>ไฟล์บนเซิร์ฟเวอร์</h3>
      <div id="serverFiles">—</div>
    </div>

    <div>
      <h3>Preview</h3>
      <div id="pdfContainer">—</div>
    </div>
  </div>

  <script>
    const PDF_URL = "/supplies/pdf/template";
    let pdfDoc = null;

    function loadPdfPreview() {
      const container = document.getElementById('pdfContainer');
      container.innerHTML = '';
      const loadingTask = pdfjsLib.getDocument(PDF_URL);
      loadingTask.promise.then(pdf => {
        pdfDoc = pdf;
        const total = pdf.numPages;
        for (let i = 1; i <= total; i++) renderPage(i, container);
      }).catch(() => {
        container.textContent = "ยังไม่มี template หรือเปิดไม่ได้";
      });
    }

    function renderPage(num, container) {
      pdfDoc.getPage(num).then(page => {
        const viewport = page.getViewport({ scale: 1.0 });
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        container.appendChild(canvas);
        page.render({ canvasContext: ctx, viewport }).promise.then(() => {});
      });
    }

    function loadBookmarks() {
      fetch('/supplies/pdf/bookmarks')
        .then(r => r.json())
        .then(list => {
          const el = document.getElementById('bookmarkList');
          el.innerHTML = '';
          if (!list || list.length === 0) {
            el.textContent = 'ไม่พบบุ๊กมาร์ก';
            return;
          }
          list.forEach(b => {
            const div = document.createElement('div');
            div.className = 'bookmark';
            div.style.paddingLeft = (b.level * 12) + 'px';
            div.textContent = `[p.${b.pageIndex+1}] ${b.title}`;
            div.onclick = () => {
              document.getElementById('pageNumber').value = b.pageIndex + 1;
            };
            el.appendChild(div);
          });
        })
        .catch(() => document.getElementById('bookmarkList').textContent = 'โหลดบุ๊กมาร์กล้มเหลว');
    }

    function loadServerFiles() {
      fetch('/supplies/pdf/serverFiles')
        .then(r => r.json())
        .then(list => {
          const sel = document.getElementById('serverFile');
          const box = document.getElementById('serverFiles');
          sel.innerHTML = '<option value="">—</option>';
          box.innerHTML = '';
          if (!list || list.length === 0) {
            box.textContent = 'ไม่มีไฟล์';
            return;
          }
          list.forEach(fn => {
            sel.insertAdjacentHTML('beforeend', `<option value="${fn}">${fn}</option>`);
            box.insertAdjacentHTML('beforeend', `<div>${fn}</div>`);
          });
        });
    }

    // Toggle replaceCount
    document.getElementById('actionType').addEventListener('change', (e) => {
      document.getElementById('replaceCountWrap').style.display =
        e.target.value === 'replaceRange' ? 'block' : 'none';
    });

    document.getElementById('templateForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      fetch('/supplies/pdf/uploadTemplate', { method: 'POST', body: fd })
        .then(r => r.ok ? r.text() : r.text().then(t=>Promise.reject(t)))
        .then(() => { loadBookmarks(); loadPdfPreview(); })
        .catch(err => alert('อัปโหลดล้มเหลว: ' + err));
    });

    document.getElementById('btnReload').addEventListener('click', () => {
      loadBookmarks();
      loadPdfPreview();
    });

    document.getElementById('btnReloadServerFiles').addEventListener('click', loadServerFiles);

    document.getElementById('editForm').addEventListener('submit', (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      fetch('/supplies/pdf/edit', { method: 'POST', body: fd })
        .then(r => r.ok ? r.json() : r.text().then(t=>Promise.reject(t)))
        .then(js => {
          document.getElementById('editMsg').textContent = js.message || 'สำเร็จ';
          loadBookmarks();
          loadPdfPreview();
        })
        .catch(err => {
          document.getElementById('editMsg').textContent = 'ผิดพลาด: ' + err;
        });
    });

    // init
    loadBookmarks();
    loadServerFiles();
    loadPdfPreview();
  </script>
</body>
</html>
