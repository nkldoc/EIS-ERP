<?php
header('Content-Type: application/json; charset=utf-8');

$raw = file_get_contents('php://input');
if ($raw === false) { echo json_encode(['success'=>false, 'message'=>'no input']); exit; }

$data = json_decode($raw, true);
if (!$data || empty($data['pr_id']) || empty($data['doc_id'])) {
  echo json_encode(['success'=>false, 'message'=>'missing pr_id/doc_id']); exit;
}

$pr = preg_replace('/[^A-Za-z0-9_\-]/', '', $data['pr_id']);
$doc = preg_replace('/[^A-Za-z0-9_\-]/', '', $data['doc_id']);
$fname = "{$pr}_{$doc}.json";

// โฟลเดอร์ปลายทาง (ปรับให้ตรง env ของคุณ)
$dir = __DIR__ . '/json';
if (!is_dir($dir)) { mkdir($dir, 0775, true); }

$full = $dir . '/' . $fname;
$ok = file_put_contents($full, json_encode($data, JSON_UNESCAPED_UNICODE|JSON_PRETTY_PRINT));

if ($ok === false) {
  echo json_encode(['success'=>false, 'message'=>'write failed']); exit;
}

// ถ้ามี public url ก็ส่งกลับ
$publicUrl = '/supplies/sp/app/json/' . $fname;

echo json_encode(['success'=>true, 'file'=>$full, 'url'=>$publicUrl]);
