Ext.HDR_ID = null;
function syncToIframe() {
    try {
        var iframe = document.getElementById("signIframeID");
        var iframeDoc = iframe.contentWindow || iframe.contentDocument;

        if (iframeDoc.document)
            iframeDoc = iframeDoc.document;

        // ดึงค่าจาก ExtJS input
        var filename = Ext.getCmp("filenameID").getValue();
        var foldername = Ext.getCmp("foldernameID").getValue();
        var pages = Ext.getCmp("showPagesID").getValue();
        var docIdParam = Ext.getCmp("document_type_idID").getValue();
//        var previewSig = Ext.getCmp("previewSigID").getValue();

        // sync ค่าไปยัง input ภายใน iframe
        iframeDoc.getElementById("filenameID").value = filename;
        iframeDoc.getElementById("foldernameID").value = foldername;
        iframeDoc.getElementById("showPagesID").value = pages;
        iframeDoc.getElementById("docIdParamID").value = docIdParam;
//        iframeDoc.getElementById("previewSigID").value = previewSig;

    } catch (err) {
        console.error("ไม่สามารถ sync ข้อมูลไปยัง iframe:", err);
    }
}
const saveHdr = function (type) {
    let msg = "";
    if (Ext.getCmp("c_name").getValue() == "") {
        msg += "<span style='white-space: nowrap;'>- กรุณากรอก ผู้ดำเนินการ</span><br>";
    }

    if (msg == "") {
        Ext.getCmp("frm-Add")
                .getEl()
                .mask("Please wait...", "x-mask-loading");
        Ext.Ajax.request({
            url: "api/mn_poEmp.php",
            method: "POST",
            params: {
                mode: Ext.getCmp("role-form-mode").getValue(),
                id: Ext.getCmp("id").getValue(),
                c_name: Ext.getCmp("c_name").getValue(),
                c_comment: Ext.getCmp("c_comment").getValue()
            },
            success: function (result, request) {
                Ext.getCmp("frm-Add")
                        .getEl()
                        .unmask();
                let jsonData = Ext.util.JSON.decode(result.responseText); //decode json
                if (jsonData.success == true) {
                    Ext.store.load({params: {mode: ""}});
                    Ext.Msg.alert("แจ้งเตือน", "บันทึกเรียบร้อย");
                    Ext.getCmp("contenterCenter").remove(Ext.getCmp("frm-Add"), true) || {};
                } else {
                    Ext.MessageBox.alert("แจ้งเตือน", jsonData.msg);
                }
            },
            failure: function (result, request) {
                Ext.MessageBox.alert("Failed", result.responseText); // connect error
            }
        });
    } else {
        Ext.Msg.alert("แจ้งเตือน", msg);
    }
}; // saveHdr
const Obj_MutiSave = [
    {
        xtype: "buttongroup",
        frame: false,
        items: [
            {xtype: "label", text: "วันที่ทำรายการ : ", style: "font-size: 14px; "},
            {xtype: "tbspacer", width: 4},
            {
                xtype: "datefield",
                id: "d_doc_date",
                style: "font-size: 14px;",
                width: 100,
            },
            {xtype: "tbspacer", width: 100},
        ],
    },
    {
        xtype: "buttongroup",
        frame: false,
        items: [
            {xtype: "label", text: "รักษาการแทน : ", style: "font-size: 14px; "},
            {xtype: "tbspacer", width: 4},
            {
                xtype: "checkbox",
                id: "i_instead_cost_sign",
                // boxLabel: "รักษาการแทน",
                inputValue: 1,
                checked: false,
                listeners: {
                    check: function (combo, newValue) {
                        if (newValue) {
                            Ext.getCmp("c_instead_cost_sign").show();
                            Ext.getCmp("c_instead_cost_sign").setValue("รักษาการแทนหัวหน้าฝ่าย");
                        } else {
                            Ext.getCmp("c_instead_cost_sign").hide();
                        }
                    },
                },
            },
            {xtype: "tbspacer", width: 183},
        ],
    },
    {
        xtype: "buttongroup",
        frame: false,
        items: [
            // { xtype: "tbspacer", width: 4 },
            {
                xtype: "textfield",
                hidden: true,
                id: "c_instead_cost_sign",
                name: "c_instead_cost_sign",
                style: "color: blue;",
                width: 200,
                value: "รักษาการแทนหัวหน้าฝ่าย",
            },
            {xtype: "tbspacer", width: 201},
                    // { xtype: "tbspacer", width: 100 },
        ],
    },
    {
        xtype: "buttongroup",
        frame: false,
        items: [
            {xtype: "label", text: "หมายเหตุ : ", style: "font-size: 14px; "},
            {xtype: "tbspacer", width: 4},
            {
                xtype: "textarea",
                fieldLabel: "หมายเหตุ",
                id: "c_comment_status",
                height: 40, // Set the height here
                width: 200,
            },
        ],
    },
]; // Obj_MutiSave
// Class Extend

Ext.fnTrigger = (combo) => {
    combo.store.load({
        callback: function () {
            combo.onTriggerClick(); // Auto-open dropdown 
        }
    });
};

formAdd = function (args) {
    Ext.ns('Ext.ux.Button');
    Ext.ns('Ext.ux.Grid');
    Ext.ns('Ext.Window');
    Ext.rec = args;

    //create the data store
    /*
     var record = Ext.data.Record.create([
     {
     name: "dc_menu_id",
     type: "int",
     },
     {
     name: "menu",
     },
     {
     name: "i_show",
     type: "bool",
     },
     {
     name: "i_read_self",
     type: "bool",
     },
     {
     name: "i_read_cost",
     type: "bool",
     },
     {
     name: "i_read_all",
     
     type: "bool",
     },
     {
     name: "i_read_overall",
     type: "bool",
     },
     {
     name: "i_per_add",
     type: "bool",
     },
     {
     name: "i_per_update",
     type: "bool",
     },
     {
     name: "i_per_delete",
     type: "bool",
     },
     {
     name: "_id",
     type: "int",
     },
     {
     name: "_level",
     type: "int",
     },
     {
     name: "_lft",
     type: "int",
     },
     {
     name: "_rgt",
     type: "int",
     },
     {
     name: "_is_leaf",
     type: "bool",
     },
     ]);
     
     var storePermission = new Ext.ux.maximgb.tg.NestedSetStore({
     autoLoad: true,
     storeId: "storePermission",
     url: "api/mnDcUserDcGroupMenu.php?mode=right",
     
     reader: new Ext.data.JsonReader(
     {
     id: "_id",
     root: "data",
     totalProperty: "total",
     successProperty: "success",
     },
     record
     ),
     });*/

    var store = new Ext.data.JsonStore({
        storeId: "myStore",
        autoDestroy: false,
        autoLoad: true,
        url: "./app/api/ListDcUser.php",
        baseParams: {
            i_read: user_right_read,
        }, //Permission i_read
        root: "data",
        idProperty: "id",
        totalProperty: "totalCount",
        fields: [
            {name: "no", type: "int"},
            {name: "id"},
            {name: "menu_hdr_id"},
            {name: "dc_user_id"},
            {name: "dc_emp_id"},
            {name: "c_name"},
            {name: "c_full_name"},
            {name: "full_name"},
            {name: "position_name"},
            {name: "action"},
            {name: "org_name"},
            {
                name: 'sign_date'
            },
            {name: "row"},
            {name: "col"},
            {name: "type_id"},
            {name: "line"},
            {name: "page"},
            {name: "position_x"},
            {name: "position_y"},
            //  type_id	page	position_x	position_y	line
//type_id,	line,	dc_user_id,	full_name,	position_name,	action,	org_name,	sign_date,	row,	col             
            {name: "dc_cost_id"},
            {name: "c_user_name"},
            {name: "c_sub_name_eng"},
            {name: "c_email"},
            {name: "c_name"},
            {name: "c_password"},
            {name: "c_comment"},
            {name: "i_type_user"},
            {name: "i_enable"},
            {name: "i_delete"},
            {name: "dc_user_create_id"},
            {name: "dc_user_create_cost_id"},
            {name: "d_create"},
            {name: "dc_user_update_id"},
            {name: "dc_user_update_cost_id"},
            {name: "d_update"},
        ]
    });


    Ext.customEditor = new Ext.form.TriggerField({
        triggerClass: 'x-form-search-trigger', // shows the search icon
        editable: false,
        onTriggerClick: function () {
            // Show your custom window here


            if (!Ext.getCmp('win-grid-empID')) {

                var ss = new Ext.Window({
                    title: 'บันทีกผู้ลงนาม',
                    id: 'win-grid-empID',
                    modal: true,
                    maximizable: true,
                    closable: true,
                    listeners: {
                        afterrender: function (obj, eOpts)
                        {

                            this.fn = function (d, h) { //percentage
                                var width = Ext.getBody().getViewSize().width * d;
                                var height = Ext.getBody().getViewSize().height * h;
                                this.setSize(width, height);
                                this.setTitle(Ext.getCmp('tabpanelGridEmp').lastSelectionText);
                            };
                            this.fn(0.8, 0.8);
                        },
                        "maximize": function (window, opts) { //when property minimizable
                            window.setWidth(Ext.getBody().getViewSize().width * 0.99);
                            window.setHeight(Ext.getBody().getViewSize().height * 0.99);
                            window.expand('', false);
                            window.center();
                            Ext.getCmp('tabpanelGridEmp').setWidth(Ext.getBody().getViewSize().width * 0.98);
                            Ext.getCmp('tabpanelGridEmp').setHeight(Ext.getBody().getViewSize().height * 0.98);
                        }
                    },
                    items: [{

                            title: "แสดงข้อมูลผู้ใช้งานระบบ",
                            xtype: "grid",
                            id: "tabpanelGridEmp",
                            border: false,
                            stripeRows: true,
                            layout: {
                                type: 'vbox',
                                align: 'stretch'  // Child items are stretched to full width
                            },
                            defaults: {
                                xtype: 'textfield'
                            },
                            listeners: {
                                afterrender: function (obj, eOpts)
                                {
                                    cellClick_choose = (grid, rowIndex, columnIndex, e) => {

                                        var rec = Ext.getCmp('tabpanelGridEmp').getStore().getAt(rowIndex);


                                        if (rec) {
                                            var gridSub = Ext.getCmp('grid-step-sign-doc').getSelectionModel().getSelectedCell();
                                            var recs = Ext.getCmp('grid-step-sign-doc').getStore().getAt(gridSub[0]);
                                            Ext.approveLine = 5; //line approved
                                            Ext.action = (recs.get('line') == Ext.approveLine) ? "ปฏิบัติการแทนอธิการบดี" : "คณะแพทยศาสตร์วชิรพยาบาล";
                                            Ext.orgName = "มหาวิทยาลัยนวมินทราธิราช";

                                            recs.set("line", recs.get('line'));
                                            recs.set("dc_user_id", rec.get('dc_user_id'));
                                            recs.set("dc_emp_id", rec.get('dc_emp_id'));
                                            recs.set("full_name", "(" + rec.get('c_full_name') + ")");
                                            recs.set("position_name", null);
                                            recs.set("action", Ext.action);
                                            recs.set("org_name", Ext.orgName);
                                            recs.set("c_approved", rec.get("org_name"));
                                            recs.set("sign_date", rec.get("sign_date"));
//                                            recs.commit();
                                            Ext.getCmp('win-grid-empID').destroy();
                                        } else {
                                            Ext.Msg.alert("แจ้งเตือน", "กรุณาเลือกรายการที่จะลบ");
                                        }

                                    };

                                    this.on('cellclick', cellClick_choose, this);
                                    this.fn = function (d, h) { //percentage
                                        var width = Ext.getBody().getViewSize().width * d;
                                        var height = Ext.getBody().getViewSize().height * h;
                                        this.setSize(width, height);
                                        this.setTitle(Ext.getCmp('tabpanelGridEmp').lastSelectionText);
                                    };
                                    this.fn(0.79, 0.8);
                                },

                            },
                            loadMask: true,
                            store: store,
                            tbar: ["",
                                "", new Ext.form.TwinTriggerField({
                                    xtype: 'twintriggerfield',
                                    text: "ค้นหาจากใบล่าสุด",
                                    trigger1Class: 'x-form-clear-trigger',
                                    trigger2Class: 'x-form-search-trigger',
                                    listeners: {
                                        specialkey: function (field, e) {
                                            if (e.getKey() === e.ENTER) {
                                                if (field.getValue() !== "") {
                                                    field.onTrigger2Click();  //  
                                                } else {
                                                    field.onTrigger1Click();  //  
                                                }
                                            }
                                        }
                                    },

                                    onTrigger1Click: function ( ) {
                                        this.setValue('');
                                        store.setBaseParam("mode", "");
                                        Ext.getCmp("tabpanelGridEmp").getStore().load();

                                    }, onTrigger2Click: function ( ) {
//                                        alert(2);
                                        store.setBaseParam("mode", "SEARCH");
                                        store.setBaseParam("filter", Ext.getCmp("filterEmpID").getValue());
                                        store.setBaseParam("value", this.getValue());
                                        Ext.getCmp("tabpanelGridEmp").getStore().load();
                                    }
                                }), {
                                    text: "ค้นหาจากใบล่าสุด",
                                    iconCls: "icon-magnifier",
                                    handler: function () {
                                        store.setBaseParam("mode", "LastGenDoc");
                                        Ext.getCmp("tabpanelGridEmp").getStore().load();
                                    }
                                },
                                {
                                    xtype: "tbfill",
                                },
                                "",
                                "",
                                "-",
                                {
                                    id: "filterEmpID",
                                    xtype: "combo",
                                    width: 130,
                                    mode: "local",
                                    store: new Ext.data.SimpleStore({
                                        fields: ["value", "text"],
                                        data: [
                                            ["c_full_name", "ชื่อพนักงาน"],
                                            ["c_user_name", "ชื่อผู้ใช้งานระบบ"],
                                        ],
                                    }),
                                    valueField: "value",
                                    displayField: "text",
                                    allowBlank: false,
                                    editable: false,
                                    triggerAction: "all",
                                    typeAhead: false,
                                    value: "c_full_name",
                                },
                                "-"
                            ],
                            columns: [
                                new Ext.grid.RowNumberer({
                                    width: 35,
                                    header: " No ",
                                    renderer: function (value, metaData, record, row, col, store, gridView) {
                                        return record.get("no");
                                    },
                                }),
                                {
                                    header: "ID System",
                                    sortable: true,
                                    hidden: true,
                                    dataIndex: "id",
                                },
                                {
                                    header: "อัพเดทเมนู",
                                    sortable: true,
                                    dataIndex: "id",
                                    renderer: function (value, metaData, record, row, col, store, gridView) {
                                        return record.get("menu_hdr_id") > 0 ? '<button id="buUpdaeMenu" onclick="Ext.runx(' + record.get("menu_hdr_id") + "," + record.get("id") + ')">updateMenu</button>' : "";
                                    },
                                },
                                {
                                    header: "ชื่อผู้ใช้งานระบบ",
                                    sortable: true,
                                    dataIndex: "c_user_name",
                                },

                                {
                                    id: "c_full_name",
                                    header: "ชื่อพนักงาน",
                                    sortable: true,
                                    dataIndex: "c_full_name",
                                },
                                {
                                    sortable: false,
                                    width: 150,
                                    align: "center",
                                    renderer: function (value, metaData, record, row, col, store, gridView) {
                                        return record.get("i_enable") ? '<img src="../images/icons/yes.gif");/>' : '<img src="../images/icons/no.gif");/>';
                                    },
                                },
                            ],
                            clicksToEdit: 1,
                            autoExpandColumn: "c_full_name",
                            bbar: (pagingBar = new Ext.PagingToolbar({
                                pageSize: 20,
                                store: store,
                                displayInfo: true,
                                displayMsg: "Displaying topics {0} - {1} of {2}",
                            })),

                        }]
                }).show();
            }
        }
    });



    var gridOnSave = (gridId) => {

        const gridID = gridId;
        const grid = Ext.getCmp(gridID);
        const store = grid.getStore();

//        if (store.getCount() === 0) {
//            Ext.Msg.alert('แจ้งเตือน', 'ไม่มีข้อมูลในตาราง');
//            return;
//        }

        const dataToSave = [];

        store.each(function (record) {
            record.set('page', Ext.getCmp('pageID').getValue());
            record.set('c_approved', Ext.getCmp('c_approveID').getValue());
            record.set('position_y', Ext.getCmp('position_yID').getValue());
            record.set('sp_sign_type_id', Ext.getCmp('sp_sign_type_idID').getValue());
            record.set('position_name', record.get('c_postion'));
            record.set('sp_tor_id', Ext.getCmp('sp_tor_idID').getValue());
//            record.set('sign_date', Ext.util.Format.date(record.get('sign_date'), 'Y-m-d'); //Ext.util.Format.date(record.get('sign_date')), 'Y-m-d')
            dataToSave.push(record.data);
        });

        console.log('ข้อมูลที่จะแก้ไข:', dataToSave);
        console.log('storeRecord Main :', Ext.recMain);
//        return false;
        // TODO: ส่งข้อมูลไปยังเซิร์ฟเวอร์ด้วย Ajax

        Ext.Ajax.request({
            url: './app/api/mnSigner.php',
            method: 'POST',
            jsonData: {
                mode: (Ext.butt !== "EDIT") ? 'add' : 'edit', // หรือ 'add', 'delete' ตามกรณี 
                sp_sign_type_id: Ext.recMain.get('sp_sign_type_id'),
                document_id: Ext.recMain.get('document_id'),
                sp_tor_id: Ext.recMain.get('sp_tor_id'),
                page: Ext.getCmp('pageID').getValue(),
                position_y: Ext.getCmp('position_yID').getValue(),
                c_approve: Ext.getCmp('c_approveID').getValue(),
                record: dataToSave    // ส่ง 1 record ถ้าเป็นแบบหลาย record ต้องวนลูปทีละตัว
            },
            success: function (response) {
                const res = Ext.decode(response.responseText);

                if (res.success === 'success') {
                    Ext.Msg.alert('สำเร็จ', res.message || 'บันทึกข้อมูลเรียบร้อยแล้ว');
                    store.commitChanges();
                    var tabPanel = Ext.getCmp('tabMainID');
                    var tabBarItem = tabPanel.items.get(1);
                    if (tabBarItem && tabBarItem.disabled) {
                        tabBarItem.enable();
                        Ext.getCmp('document_idID').setValue(res.id);
                    }
                    Ext.getCmp('tabpanel1').getStore().reload();
//                    Ext.getCmp("contenterCenter").remove(Ext.getCmp("frm-Add"), true) || {};
//                    tabPanel.setActiveTab(1);
                } else {
                    Ext.Msg.alert('ผิดพลาดในการบันทึก', res.message || '<span style="white-space: nowrap;">เกิดข้อผิดพลาด/มีการบันทึกซ้ำ</span>');
                }
            },
            failure: function (response) {
                Ext.Msg.alert('ผิดพลาด', '<span style="white-space: nowrap;">ไม่สามารถติดต่อเซิร์ฟเวอร์ได้</span>');
            }
        });
    };

    Ext.gridOnSave2 = (gridId) => {
        const gridID = gridId;
        const grid = Ext.getCmp(gridID);
        const store = grid.getStore();
//        Ext.example.msg("แจ้งเตือน", 'กรุณาเลือกรายการที่จะลบ gridId 2 ' + gridId, 1);


        const dataToSave = [];
        console.log(Ext.getCmp(gridId + '_pageID').getValue());
//return false;
        store.each(function (record) {
            record.set('page', Ext.getCmp(gridId + '_pageID').getValue());
            record.set('c_approved', Ext.getCmp('c_approveID').getValue());
            record.set('position_y', Ext.getCmp(gridId + '_position_yID').getValue());
            record.set('sp_sign_type_id', Ext.getCmp('sp_sign_type_idID').getValue());
            record.set('position_name', record.get('c_postion'));
            record.set('sp_tor_id', Ext.getCmp('sp_tor_idID').getValue());
//            record.set('sign_date', Ext.util.Format.date(record.get('sign_date'), 'Y-m-d'); //Ext.util.Format.date(record.get('sign_date')), 'Y-m-d')
            dataToSave.push(record.data);
            Ext.Ajax.request({
                url: './app/api/mnSigner.php',
                method: 'POST',
                jsonData: {
                    mode: (Ext.butt !== "EDIT") ? 'add' : 'edit', // หรือ 'add', 'delete' ตามกรณี 
                    sp_sign_type_id: Ext.recMain.get('sp_sign_type_id'),
                    document_id: Ext.recMain.get('document_id'),
                    sp_tor_id: Ext.recMain.get('sp_tor_id'),
                    page: Ext.getCmp(gridId + '_pageID').getValue(),
                    position_y: Ext.getCmp(gridId + '_position_yID').getValue(),
                    c_approve: Ext.getCmp('c_approveID').getValue(),
                    record: dataToSave    // ส่ง 1 record ถ้าเป็นแบบหลาย record ต้องวนลูปทีละตัว
                },
                success: function (response) {
                    const res = Ext.decode(response.responseText);

                    if (res.success === 'success') {
                        Ext.Msg.alert('สำเร็จ', res.message || 'บันทึกข้อมูลเรียบร้อยแล้ว');
                        store.commitChanges();
                        var tabPanel = Ext.getCmp('tabMainID');
                        var tabBarItem = tabPanel.items.get(1);
                        if (tabBarItem && tabBarItem.disabled) {
                            tabBarItem.enable();
                            Ext.getCmp('document_idID').setValue(res.id);
                        }
                        Ext.getCmp('tabpanel1').getStore().reload();
//                    Ext.getCmp("contenterCenter").remove(Ext.getCmp("frm-Add"), true) || {};
//                    tabPanel.setActiveTab(1);
                    } else {
                        Ext.Msg.alert('ผิดพลาดในการบันทึก', res.message || '<span style="white-space: nowrap;">เกิดข้อผิดพลาด/มีการบันทึกซ้ำ</span>');
                    }
                },
                failure: function (response) {
                    Ext.Msg.alert('ผิดพลาด', '<span style="white-space: nowrap;">ไม่สามารถติดต่อเซิร์ฟเวอร์ได้</span>');
                }
            });
        });

    };
    Ext.gridOnSave3 = (gridId) => {
        const gridID = gridId;
        const grid = Ext.getCmp(gridID);
        const store = grid.getStore();

//        Ext.example.msg("แจ้งเตือน", 'กรุณาเลือกรายการที่จะลบ gridId 3 ' + gridId, 1);

        const dataToSave = [];

        store.each(function (record) {
            record.set('page', Ext.getCmp(gridId + '_pageID').getValue());
            record.set('c_approved', Ext.getCmp('c_approveID').getValue());
            record.set('position_y', Ext.getCmp(gridId + '_position_yID').getValue());
            record.set('sp_sign_type_id', Ext.getCmp('sp_sign_type_idID').getValue());
            record.set('position_name', record.get('c_postion'));
            record.set('sp_tor_id', Ext.getCmp('sp_tor_idID').getValue());
//            record.set('sign_date', Ext.util.Format.date(record.get('sign_date'), 'Y-m-d'); //Ext.util.Format.date(record.get('sign_date')), 'Y-m-d')
            dataToSave.push(record.data);
            Ext.Ajax.request({
                url: './app/api/mnSigner.php',
                method: 'POST',
                jsonData: {
                    mode: (Ext.butt !== "EDIT") ? 'add' : 'edit', // หรือ 'add', 'delete' ตามกรณี 
                    sp_sign_type_id: Ext.recMain.get('sp_sign_type_id'),
                    document_id: Ext.recMain.get('document_id'),
                    sp_tor_id: Ext.recMain.get('sp_tor_id'),
                    page: Ext.getCmp(gridId + '_pageID').getValue(),
                    position_y: Ext.getCmp(gridId + '_position_yID').getValue(),
                    c_approve: Ext.getCmp('c_approveID').getValue(),
                    record: dataToSave    // ส่ง 1 record ถ้าเป็นแบบหลาย record ต้องวนลูปทีละตัว
                },
                success: function (response) {
                    const res = Ext.decode(response.responseText);

                    if (res.success === 'success') {
                        Ext.Msg.alert('สำเร็จ', res.message || 'บันทึกข้อมูลเรียบร้อยแล้ว');
                        store.commitChanges();
                        var tabPanel = Ext.getCmp('tabMainID');
                        var tabBarItem = tabPanel.items.get(1);
                        if (tabBarItem && tabBarItem.disabled) {
                            tabBarItem.enable();
                            Ext.getCmp('document_idID').setValue(res.id);
                        }
                        Ext.getCmp('tabpanel1').getStore().reload();
//                    Ext.getCmp("contenterCenter").remove(Ext.getCmp("frm-Add"), true) || {};
//                    tabPanel.setActiveTab(1);
                    } else {
                        Ext.Msg.alert('ผิดพลาดในการบันทึก', res.message || '<span style="white-space: nowrap;">เกิดข้อผิดพลาด/มีการบันทึกซ้ำ</span>');
                    }
                },
                failure: function (response) {
                    Ext.Msg.alert('ผิดพลาด', '<span style="white-space: nowrap;">ไม่สามารถติดต่อเซิร์ฟเวอร์ได้</span>');
                }
            });
        });

    };
    var grid = new Ext.grid.EditorGridPanel({
//    title: 'Editable Grid',
        id: 'grid-step-sign-doc',
        layout: "fit",
        border: true,

        tbar: [{
                text: "เพิ่มรูปแบบที 2 ตำแหน่ง",
                iconCls: "icon-user-group-save",
                handler: function () {


                    if (!Ext.getCmp('tab2')) {

                        Ext.getCmp('tabMainID').add({
                            title: "วางลายเซ็นแบบที่ 2 ตำแหน่ง",
                            iconCls: "icon-vcard",
                            id: "tab2",
                            closable: true,
                            layout: "fit",
                            items: [Ext.createGrid("grid-copy1", Ext.getCmp('grid-step-sign-doc').getStore())]
                        });
                        Ext.getCmp('tabMainID').setActiveTab('tab2');
                    } else {
                        Ext.getCmp('tabMainID').setActiveTab('tab2');
                    }
                }
            },
            {
                text: "เพิ่มรูปแบบที่ 1 ตำแหน่ง",
                iconCls: "icon-user-group-save",
                handler: function () {
                    if (!Ext.getCmp('tab3')) {

//console.log(Ext.getCmp('grid-step-sign-doc').getStore());
// 
//return false;
                        Ext.getCmp('tabMainID').add({
                            title: " วางลายเซ็นแบบที่ 1 ตำแหน่ง",
                            iconCls: "icon-vcard",
                            id: "tab3",
                            layout: "fit",
                            closable: true,
                            items: [Ext.createGrid("grid-copy2", Ext.getCmp('grid-step-sign-doc').getStore())]
                        });
                        Ext.getCmp('tabMainID').setActiveTab('tab3');
                    } else {
                        Ext.getCmp('tabMainID').setActiveTab('tab3');
                    }
                }
            }, {
                xtype: "tbfill"
            },
            {xtype: "label", text: "ข้อความอนุมัติ : ", style: "padding-left:10px; font-size: 14px; "},
            {xtype: "tbspacer", width: 4},
            {
                xtype: "hidden",
                name: "sp_sign_type_id",
                id: "sp_sign_type_idID"
            },
            {
                xtype: "textfield",
                name: "c_approve",
                id: "c_approveID",
                width: 240,
                style: "font-size: 12px;",
                emptyText: "- เห็นชอบ มอบฝ่ายพัสดุดำเนินการ",
            }, {
                xtype: "buttongroup",
                frame: false,
                //                fieldLabel: "รายการ PR อ้างอิง ",
                items: [{xtype: "tbfill"},
//                    {xtype: "label", text: " วันที่เอกสาร :", style: "font-size: 14px; "},
//                    {
//                        xtype: "datefield",
//                        name: "date_document",
//                    },
                    {xtype: "label", text: " page :", style: "font-size: 14px; "},
                    {xtype: "tbspacer", width: 4},
                    {
                        xtype: "textfield",
                        id: "pageID",
                        name: "page",
                        value: "1",
                        style: "font-size: 12px;",
                        width: 80,
                    },
                    {xtype: "label", text: "ตำแหน่งแกน Y : ", style: "padding-left:10px; font-size: 14px; "},
                    {xtype: "tbspacer", width: 4},
                    {
                        xtype: "textfield",
                        id: "position_yID",
                        name: "position_y",
                        style: "font-size: 12px;",
                        width: 50,
                        value: "50",
                    },
                    {xtype: "label", text: "ขยับขึ้นลง +/- แกน Y", style: "padding-left:10px;font-size: 14px; "},
                ],
            }
        ],
        bbar: [{
                xtype: 'button', text: 'บันทึกตำแหน่ง////', iconCls: "icon-save",
                handler: function () {
                    gridOnSave('grid-step-sign-doc');
                }
            }, {
                xtype: 'button', text: 'บันทึกตำแหน่ง ', iconCls: "icon-save",
                handler: function () {
                    console.log(Ext.getCmp('grid-step-sign-doc').getStore());

                }
            }],
        viewConfig: {
            emptyText: "ไม่มีข้อมูล..",
            deferEmptyText: false,
        },
        listeners: {
            afterrender: function () {

                cellClick_del = (grid, rowIndex, columnIndex, e) => {

                    var gridSub = Ext.getCmp('grid-step-sign-doc').getSelectionModel().getSelectedCell();
                    var rec = Ext.getCmp('grid-step-sign-doc').getStore().getAt(gridSub[0]);
                    if (gridSub[1] === Ext.getCmp('grid-step-sign-doc').getColumnModel().getIndexById("dc_user_del_idID")) {
                        if (rec) {
                            Ext.getCmp('grid-step-sign-doc').getStore().remove(rec);
                        } else {
                            Ext.Msg.alert("แจ้งเตือน", "กรุณาเลือกรายการที่จะลบ");
                        }
                    }
                };
//                this.on('cellclick', cellClick_del, this);
            }
        },
        anchor: '100% 100%',
        autoScroll: true,
        store: new Ext.data.ArrayStore({
            fields: [
                {name: 'id'},
                {name: 'sp_sign_type_id'},
                {name: 'line'},
                {name: 'dc_user_id'},
                {name: 'full_name'},
                {name: 'position_name'},
                {name: 'action'},
                {name: 'c_approved'},
                {name: 'page'},
                {name: 'date_document'},
                {name: 'line_approved'},
                {name: 'position_y'},
                {name: 'org_name'},
                {name: 'sign_date'},
                {name: 'row'},
                {name: 'col'},
                {name: 'step_sign'},
                {name: 'document_id'},
                {
                    name: 'c_name',
                    convert: function (v, rec) {
                        return rec.position_name + " " + rec.full_name;
                    }
                },
                {
                    name: 'rc',
                    convert: function (v, rec) {
                        return rec.row + "," + rec.col;
                    }
                }
            ],
            data: [] //dc_user_id c_postion full_name action org_name sign_date position_x
        }),
        columns: [
            {
                header: '-',
//            hidden:true,
                menuDisabled: true,
                dataIndex: 'id', fixed: true,
                align: "center",
                width: 30,
            },
            {
                header: 'dc_user_id',
                hidden: true,
                dataIndex: 'dc_user_id',

            },
            {

                header: 'ตำแหน่ง r,c',
                align: 'center',
                dataIndex: 'rc', width: 100,
                editor: Ext.customEditorRowCol,
                id: 'position_xyID', menuDisabled: true, fixed: true,
                renderer: function (value, metaData, record, row, col, store, gridView) {
                    if (value == "") {
                        metaData.css = 'grid-icon-cell';
                        return '<img src="../images/icons/xhtml_valid.png" style="vertical-align:middle;margin-right:5px;" />' +
                                '<span style="color:red;"> ' + record.get('row') + ',' + record.get('col') + ' </span>';
                    } else {
                        return '<span style="color:blue;">' + record.get('row') + ',' + record.get('col') + '  </span>';

                    }

                }
            },
            {
                header: 'เลือกผู้ปฎิบัติหน้าที่ ', width: 230,
                dataIndex: 'c_postion', menuDisabled: true, fixed: true,
                id: 'dc_user_idID',
                editor: Ext.customEditor,
                iconCls: "icon-vcard",
                renderer: function (value, metaData, record, row, col, store, gridView) {
                    if (!value || value == 0) {
                        metaData.css = 'grid-icon-cell';
                        return '<img src="../images/icons/user_add.png" style="vertical-align:middle;margin-right:5px;" />' +
                                '<span style="color:red;"> แก้ไข ' + value + '</span>';
                    } else {
                        return '<img src="../images/icons/user_edit.png" style="vertical-align:middle;margin-right:5px;" />' +
                                '<span style="color:blue;"> เลือก ' + value + '</span>';
                    }

                }
            },
            {

                header: 'เจ้าหน้าที่ดำเนินการลงนาม',
                dataIndex: 'full_name', width: 200,
                editor: new Ext.form.TextField({
                    allowBlank: false
                })
//            },
//            {
//
//                header: 'ปฎิบัติหน้าที่แทน',
//                dataIndex: 'position_name', width: 150,
//                editor: new Ext.form.TextField({
//                    allowBlank: false
//                })
            },
            {

                header: 'ส่วนงาน/ปฎิบัติหน้าที่',
                dataIndex: 'action', width: 200,
                editor: new Ext.form.TextField({
                    allowBlank: false
                })
            },
            {

                header: 'องค์กร/สังกัด',
                dataIndex: 'org_name', width: 150,
                editor: new Ext.form.TextField({
                    allowBlank: false
                })
            }, {
                header: "วันที่ลงนาม",
                sortable: true,
                align: "center",
                dataIndex: "sign_date",
                width: 120,
                renderer: function (value, metaData, record, rowIndex, colIndex, store) {
                    return shortThaiDate(value);

                },
                editor: new Ext.form.DateField()
            }
        ],
        clicksToEdit: 1

    });
    Ext.sing_stemp_doc = [{
            xtype: "container",
            layout: "hbox",
            align: "stretch",
            RemoveHeight: true,
            defaults: {xtype: "fieldset", flex: 1, margins: "0px 3px", autoHeight: true},
            items: [
                {
                    title: "บันทึกข้อมูล " + Ext.title,
                    RemoveCls: "x-box-item",
                    collapsible: true,
                    collapsed: false,
                    id: "fromGroupID",
                    defaults: {labelStyle: "width:200px;", allowBlank: true},
                    items: [
                        {
                            xtype: "hidden",
                            id: "role-form-mode",
                            name: "mode",
                            readOnly: true
                        },
                        {
                            xtype: "hidden",
                            id: " step_document_id", //  step_sign status_approve approve_by
                            name: "step_document_id",
                            readOnly: true

                        },
                        {
                            xtype: "hidden",
                            id: "id",
                            name: "id",
                            readOnly: true
                        },
                        {
                            xtype: "hidden",
                            id: "sp_tor_idID",
                            name: "sp_tor_id",
                            readOnly: true
                        },
                        {
                            xtype: "hidden",
                            id: "document_idID",
                            name: "document_id"
                        },
                        {
                            xtype: "buttongroup",
                            frame: false,
                            fieldLabel: "รายการ PR อ้างอิง ",
                            items: [
//                            {xtype: "label", text: "รายการ PR อ้างอิง : ", style: "font-size: 14px; "},
//                            {xtype: "tbspacer", width: 4},
                                {
                                    xtype: "textfield",
                                    id: "d_doc_ref",
                                    name: "d_doc_ref",
                                    style: "font-size: 14px;",
                                    width: 100,
                                },
                                {xtype: "tbspacer", width: 4},
                                Ext.PopChoosePRForm.mini
                            ],
                        },
                        {
                            xtype: "displayfield",
                            fieldLabel: "วิธีดำเนินงาน",
//                            value: "* ระบุหน้าที่ต้องการลงนาม เช่น 1,2,5",
                            name: 'tor_type_idTxt',
                            id: 'tor_type_idTxtID',
                            style: "color: blue; font-style: italic;"
                        },
                        new Ext.form.ComboBox({
                            fieldLabel: "เอกสารที่ดำเนินการ",
                            mode: "local",
                            store: Ext.sp_status_document_items,
                            id: "document_type_idID",
                            hiddenName: "document_type_id",
                            name: "document_type_id",
                            valueField: "id",
                            displayField: "c_name",
                            width: 400,
                            triggerAction: "all",
                            forceSelection: true,
                            selectOnFocus: true,
                            typeAhead: false,
                            emptyText: "กรุณาเลือก...",
                            resizable: true, // optional for manual resizing
                            listeners: {
                                afterrender: function (combo) {
                                    Ext.fnTrigger(combo);
                                    this.fn = function () {
                                        Ext.getCmp("frm-Add").getEl().mask("Please wait...", "x-mask-loading");
                                        Ext.storePrDoc.setBaseParam("type", "PRLISTSTEP02");
//                                        Ext.storeDepartments.setBaseParam("mode", "LIST");
                                        Ext.storePrDoc.setBaseParam("docType", this.getValue());
                                        Ext.storePrDoc.load({
                                            callback: function (record, operation, success) {
//                                                console.log(record);
                                                Ext.getCmp("frm-Add").getEl().unmask();
                                            }
                                        });

                                    };

                                },
                                change: function () {
//                                    this.fn();
                                },
                                select: function () {
                                    this.fn();
                                },
                                beforequery: function (q) {
                                    if (q.query) {
                                        var length = q.query.length;
                                        q.query = new RegExp(Ext.escapeRe(q.query));
                                        q.query.length = length;
                                    }
                                },
                                blur: function () {
                                    this.getStore().clearFilter();
                                },
                                expand: function (cb) {
                                    // Automatically adjust list width based on longest option
                                    var max = 0;
                                    cb.store.each(function (rec) {
                                        var len = rec.get(cb.displayField).length;
                                        if (len > max) {
                                            max = len;
                                        }
                                    });

                                    var newWidth = (max * 7) + 30; // 7 is approx avg char width in px
                                    cb.list.setWidth(Math.max(cb.getWidth(), newWidth));
                                }
                            }
                        }),

                        new Ext.ux.form.LovCombo({
                            readOnly: false,
                            editable: false,
                            fieldLabel: "เจ้าหน้าที่ดำเนินการลงนาม",
                            mode: "local",
                            store: Ext.sp_signin_document,
                            id: "sign_step_doc",
                            hiddenName: "sign_step_doc", //sp_signin_document
                            name: "sign_step_doc",
                            valueField: "id",
                            displayField: "c_name",
                            width: 400,
                            triggerAction: "all",
                            forceSelection: true,
                            selectOnFocus: true,
                            typeAhead: false,
                            emptyText: "กรุณาเลือก...",
                            listeners: {
                                beforerender: function () {
                                    Ext.arr1 = [];

                                },
                                beforeselect: function (t, records, options) {
                                },
                                blur: function (t, records, options) {
//alert(this.getValue());
                                },

                                select: function (t, records, options) {
                                    var NewRecord = grid.store.recordType;  // this gets the Record constructor
                                    var newRec = new NewRecord({
//                                        id: records.get('id'),
//                                        postion_id: records.get('id'),
//                                        c_postion: records.get('c_name'),
//                                        c_name: null,
//                                        dc_user_id: null,
//                                        c_full_name: null,
//                                        c_sub_name_eng: null,
//                                        c_email: null
// Debug 
/////

                                        id: records.get('id'),
                                        dc_user_id: null,
                                        c_postion: records.get('c_name'),
                                        full_name: null,
                                        action: null,
                                        org_name: null,
                                        sign_date: null,
                                        c_approved: null,
                                        row: 1,
                                        col: 2,
                                        line: records.get('id'),
                                        rc: null,
                                        step_sign: null,
                                        document_id: null //document_id step_sign line
                                    });
                                    if (records.get('checked') === true) {
                                        grid.store.add(newRec);

                                    } else {
                                        var rec = Ext.getCmp('grid-step-sign-doc').getStore();
                                        var rs = Ext.getStoreRow(rec, records.get('id'));
                                        if (rs) {
                                            Ext.getCmp('grid-step-sign-doc').getStore().remove(rs);
                                            grid.store.remove(records);
                                        } else {
                                            Ext.example.msg("แจ้งเตือน", 'กรุณาเลือกรายการที่จะลบ', 1);

                                        }
                                    }

                                },

                                afterrender: function (combo) {
                                    // ตั้งค่า value หลายค่าเมื่อโหลดเสร็จ
                                    var defaultValues = []; // ใส่ id ของรายการที่ต้องการให้เลือก
//                                    var defaultValues = ['2', '4']; // ใส่ id ของรายการที่ต้องการให้เลือก

                                    combo.setValue(defaultValues.join(','));

                                    // optional: trigger select manually
                                    combo.getStore().each(function (rec) {
                                        if (defaultValues.indexOf(String(rec.get('id'))) !== -1) {
                                            rec.set('checked', true); // ทำให้ checkbox ติ๊กถูก
                                        }
                                    });
//                                    Ext.fnTrigger(combo);
                                }
                            }
                        }),

                        {
                            xtype: "tabpanel",
                            plain: true,
                            id: 'tabMainID',
                            activeTab: 2,
                            height: 335,
                            deferredRender: false,
                            defaults: {bodyStyle: "padding:0px"},
                            items: [
                                {
                                    title: "นำเข้าไฟล์เอกสารที่จะลงนาม",
                                    layout: "form", iconCls: "icon-download",
                                    defaults: {width: 230},
                                    defaultType: "textfield", disabled: true,
                                    autoScroll: true,
                                    html: '<iframe src="../upload/upload.php?__dc=' + (Math.floor(Math.random() * 100)) + '" frameborder="0" width="100%" height="100%"></iframe>',
                                },
                                {

                                    title: "กำหนดหน้าลงนาม PDF",
                                    layout: "form", iconCls: "icon-pdf",
                                    defaults: {width: 230},
                                    defaultType: "textfield", disabled: true,
                                    autoScroll: true,
                                    html: '<iframe src="../upload/signner5.php" id="signIframeID" frameborder="0" width="100%" height="100%"></iframe>',
                                    items: [
                                        {
                                            fieldLabel: "ชื่อไฟล์",
                                            name: "filename",
                                            id: "filenameID"
                                        },
                                        {
                                            fieldLabel: "โฟลเดอร์จัดเก็บเอกสาร",
                                            name: "foldername",
                                            id: "foldernameID"

                                        },
                                        {
                                            fieldLabel: "กำหนดหน้าเอกสารลงนาม",
                                            name: "showPages",
                                            id: "showPagesID",
//                                            emptyText: '1,2',
                                            listeners: {
                                                blur: syncToIframe
                                            }
                                        },
                                        {
                                            xtype: "displayfield",
                                            value: "* ระบุหน้าที่ต้องการลงนาม เช่น 1,2,5",
                                            style: "color: #666; font-style: italic;"
                                        }
                                    ],
                                }, {
                                    title: "ลงนามเอกสาร วางลายเซ็นแบบที่ 5 ตำแหน่ง",
                                    iconCls: "icon-vcard",
                                    id: 'step_sign_doc',
                                    items: [grid],
                                    layout: 'fit',
                                    closable: true
                                },
                            ],
                        }]
                }]}];

    formAdd.superclass.constructor.call(this, {
        region: "center",
        title: "ข้อมูล " + Ext.title,
        iconCls: "icon-application-form-add",
        id: "frm-Add",
        border: false,
        stripeRows: true,
        loadMask: true,
        listeners: {
            afterrender: function (obj, eOpts) {

                Ext.getCmp("form-widgets").on('render', function () {

                    Ext.getCmp("form-widgets").getForm().items.each(function (field) {

                        field.on('blur', function (f) {
                            if (Ext.rec && f.name) {
//                                Ext.rec.set(f.name, f.getValue());
                            }
//                            Ext.example.msg("แจ้งเตือน", f.getValue(), 3);
                        });

                    });
                });



            }
        },
        items: [
            {
                xtype: "form",
                id: "form-widgets",
                frame: true,
                labelAlign: "right",
                labelWidth: 200,
                bodyStyle: {padding: "10px 20px"},
//        defaults: { anchor: "100%", msgTarget: "side", allowBlank: false, },
                defaults: {labelStyle: "width:200px;", allowBlank: true},

                items: Ext.sing_stemp_doc,
                buttonAlign: "left",
                buttons: [{
                        text: "&nbsp;บันทึกชั่วคราว&nbsp;",
                        id: "SaveTempHdr",
                        iconCls: "icon-script-save",
                        handler: function (f) {
                            Ext.getCmp("form-widgets").getForm().items.each(function (field) {
                                if (Ext.rec && f.name) {
                                    Ext.rec.set(f.name, f.getValue());
                                }
                                Ext.getCmp("form-widgets").getForm().loadRecord(Ext.rec);
                            });



                        },

                    }, {
                        text: "&nbsp;Preview PDF &nbsp;",
                        id: "priviewHdr",
                        iconCls: "icon-pdf",
                        handler: function (f) {
//                            Ext.getCmp("form-widgets").getForm().items.each(function (field) {
//                                if (Ext.rec && f.name) {
//                                    Ext.rec.set(f.name, f.getValue());
//                                }
//                                Ext.getCmp("form-widgets").getForm().loadRecord(Ext.rec);
//                            });
                            var tabPanel = Ext.getCmp('tabMainID');
                            var it = 1;
                            var tabBarItem = tabPanel.items.get(it);
                            if (tabBarItem && tabBarItem.disabled) {
                                tabBarItem.enable(); 
                                tabPanel.setActiveTab(it);
                            }


                        },

                    },
                    {
                        text: "&nbsp;" + Ext.GLOBAL_BU_SAVE_TH + "&nbsp;",
                        id: "saveHdr",
                        iconCls: "icon-save",
                        disabled: Ext.butt == "ADD" || Ext.butt == "EDIT" ? false : true,
                        handler: function () {
                            Ext.getCmp("tabpanel1").getSelectionModel().clearSelections();
                            console.log(Ext.getCmp('frm-Add'));


                            //            Ext.getCmp("form-widgets").getForm().loadRecord(rec);
                            return false;
                            saveHdr(false);
                        }
                    },
                    {
                        text: Ext.GLOBAL_BU_BACK_TH, iconCls: "icon-back",
                        handler: function () {
                            Ext.getCmp("contenterCenter").remove(Ext.getCmp("frm-Add"), true) || {};
                        }
                    }
                ],

            }
        ]
    });
}; // formAdd
Ext.extend(formAdd, Ext.Panel, {});
